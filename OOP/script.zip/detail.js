class Detail
{
    constructor(name, desc)
    {
        this.id = name.toLowerCase().replace(/\s/g, '');
        this.name = name;
        this.description = desc;
    }

    display(element)
    {
        element.innerHTML += `<div id="${this.id}">${this.name}</div>`;
    }

    getSpan()
    {
        return document.getElementById(this.id);
    }
}